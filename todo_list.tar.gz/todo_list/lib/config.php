<?php

 //OBTENEMOS LA VARIABLE DE CONEXIÓN

	$dbhost='localhost';
	$dbuser='root';
	$dbpasswd='linuxlinux';
	$dbname='tasker';

	?>