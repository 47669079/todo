<?php
        

        include 'index.php';
        include '../lib/bd.php';


        if(isset($_SESSION['email']) && isset($_SESSION['passwd'])) 
        {

        $email = $_SESSION['email']; 
        $passwd = $_SESSION['passwd'];

        }
        

        if (!empty($_POST['eliminar'])) {  //si pulsamos borrar

                $_SESSION['id'] = $_POST['id']; //guardaremos la id de la tasca que querremos borrar i la guardaremos en una variable de sesión

                header('Location:borrar.php'); //nos iremos a la cabecera de borrar

                exit();
        }
        if (!empty($_POST['agregar'])) {  //si pulsamos agregar

                $_SESSION['data'] = $_POST['data'];
                $_SESSION['completed'] = $_POST['completed'];
                $_SESSION['descripcion'] = $_POST['descripcion'];
                $_SESSION['email'] = $email;

                //guardaremos como variables de sesión los datos que hemos rellenado en el formulario

                header('Location:agregar.php'); 
                exit();
        }
        
?>
<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="UTF-8">
        <title>Llistar</title>
        <link rel="stylesheet" type="text/css" href="../assets/css/bootstrap.min.css">
</head>
<body>
        <div class="container-fluid">
                <nav class="collapse navbar-collapse">
                        
                             
                        <form method="POST" action="../index.html">
                        <input type="submit" name="logout" value="logout">
                        </form>

                </nav> 
                
        </div>
        <div class="container-fluid">
        
        <div class="text-center">
                <form method="POST" action="<?= $_SERVER['PHP_SELF'];?>">
                        <label>ELIMINAR </label><input type="text" name="id" placeholder='"num de id"'>
                        <input type="submit" name="eliminar" value="Eliminar" class="btn"><br>
                                <label>Fecha </label><input type="text" name="data" placeholder='"YYYY/MM/DD"'>
                                <label>¿Completado? </label><input type="text" name="completed" placeholder='"0/1"'>
                                <label>Tarea </label><input type="text" name="descripcion" placeholder='"tarea"'>
                        <input type="submit" name="agregar" value="agregar" class="btn">
                </form>
        </div>
        </div>

        <div class="text-center">
                
                 <ul class="list-group">
  


                <!-- LISTAR TAREAS -->
                <?php 

                $db = conecta($dbhost, $dbuser, $dbpasswd, $dbname);

                $sql = 'SELECT * FROM users INNER JOIN task ON users.id = task.user WHERE email="'.$email.'" AND passwd="'.$passwd.'";';
                
                $result=$db->query($sql);

                if(!$result=$db->query($sql)) 
                                        {
                                                die("error en listar");
                                        }
                while($rec=$result->fetch_array()) //entramos en un bucle para recorrer toda la bae de datos
                                        {
                                                if($rec['completed']==1){
                                                        echo "<li class='list-group-item'><strike>".$rec['id'].".".$rec['descripcion']."</strike></li>";

                                                        //entraremos en este if cuando hayamos dicho que la tarea si está completada, por lo tanto nos tachará la tarea
                                                }
                                                else
                                                        echo "<li class='list-group-item'>".$rec['id'].".".$rec['descripcion']."</li>";
                                                
                                        }
        
                        $db->close();
        ?>
</ul>
        </div>
                
        
</body>
</html>