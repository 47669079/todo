<?php
        session_start();

        include 'index.php';
        require '../lib/bd.php';

        $data = $_SESSION['data'];
        $completed = $_SESSION['completed'];
        $descripcion = $_SESSION['descripcion'];

        //guadaremos como variables los datos que tenemos en las variables de sesión

        if (!empty($descripcion)) { //si la variable descripción no está vacia

                $db = conecta($dbhost, $dbuser, $dbpasswd, $dbname);

                $sql = 'SELECT users.id FROM users WHERE users.email = "'.$_SESSION['email'].'" LIMIT 1;'; 

                //ejecutaremos una sentencia para guardar el id del usuario y además la aprovecharemos para saber si este usuario está en la base de datos
                
                if ($result = mysqli_query($db, $sql)) { //ejecuatamos la sentencia en la base de datos y la guardamos en result
                      
                        if ($row = mysqli_fetch_array($result)) { //guardamos en row los datos de la sentencia

                                        $id = $row[0]; //como la sentencia que hemos realizado antes para obtener el id solo nos devolverá un resultado sabemos que el id está en la posición 0 del array row

                                        $sql1 ='INSERT INTO task(id, descripcion, user, data, completed) VALUES("'.NULL.'","'.$descripcion.'","'.$id.'","'.$data.'","'.$completed.'");';

                                        //hacemos una sentencia para insertar en nuestra base de datos la tarea, además la insertaremos con el número de id del usuario que se ha dado de alta gracias a la variable id

                                        if($result=$db->query($sql1)) //si hemos realizado la sentancia correctamente
                                                {
                                                        header('Location:list.php'); //volveremos a list
                                                        exit();
                                                }
                                        else
                                                {
                                                        echo("error en borrar"); //si no nos dará error
                                                }
                                
                                }
                                else{
                                        echo ("Error en realizar la sentancia");
                                }
                        }
                        else
                        {
                                echo ("No se ha podido entrar en la base de datos"); 
                        }
        }
        else
        {
                echo ("No se ha insertado descripcion");
        }
 ?>
