<?php
	/**
	*	
	*	Inserta registres a la base da dades d'alumnes
	*	@author:olalla
	*	@version:1.0
	*	@package:lib
	*
	*
	*/

	//connexió

	
	 include 'index.php';
     include '../lib/bd.php';
		
	$mysqli=conecta($dbhost, $dbuser, $dbpasswd, $dbname);
			if ( $mysqli->connect_errno) //si no nos podemos conectar a la base de datos nos dará error
			{
				die('Error de connexió');
			}
			else //de lo contrario
			{
				
				if($_POST['email'] && !empty($_POST['email'])  &&  $_POST['passwd'] && !empty($_POST['passwd'])) //Si la variable que hemos recogido como EMAIL y PASSWD no están vacias...

				{

					//Generamos la variable sql para guardar la sentencia

					$sql="INSERT INTO users(email,passwd) VALUES('$_REQUEST[email]','$_REQUEST[passwd]')";
					
					//Ejecutamos la consulta

					if(!$result=$mysqli->query($sql)) //si se ha producido de forma incorrecta
													/*la flecha es un método de un objeto o una clase (->)*/
					{
						die("error en insert");
					}

					$mysqli->close;					

				}	

			}

	?>


	<!DOCTYPE html>
	<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>TODO</title>
		<link rel="stylesheet" type="text/css" href="../assets/css/bootstrap.min.css">
		<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
	</head>
	<body>

<nav class="navbar navbar-inverse ">
			
			
		<div id="navbar" class="collapse navbar-collapse">
			<ul class="nav navbar-nav">
					
					<li><a href="../index.html"> Home </a></li>
					<li><a href="conect.php"> Contectar-se </a></li>
			
			</ul>
		</div>
			
	</nav>


<div class="jumbotron text-center">
	
	<h1>TODO</h1>
	<p>OLALLA IGLESIAS ALCALÁ</p>	



</div>

<div class="formgroup">

<form method="POST" action="<?= $_SERVER['PHP_SELF']; ?>">

<!-- $_SERVER es un array que contiene información, tales como cabeceras, rutas y ubicaciones de script. Las entradas de este array son creadas por el servidor web

'PHP_SELF'
El nombre del archivo de script ejecutándose actualmente, relativa al directorio raíz de documentos del servidor.

 -->
			
			<p><label for="email">Email</label></p>

			<input class="form-control" type="text" name="email">

			<p><label for="passwd">Contraseña</label></p>

			<input class="form-control" type="password" name="passwd"> 

			<!-- hacemos esta caja como tipo password para que no se vea el password que vamos a escribir -->

			<input value="Registrate" type="submit" name="Insert">

</div>

		<footer class="container-fluid">
			<h6> &copy; DAW2 - CEFP NURIA 2016 </h6>
		</footer>

	</body>
	</html>