<?php


	include 'index.php';
	include '../lib/bd.php';

	if(!empty($_POST)){

		if(!empty($_POST['email']) && !empty($_POST['passwd'])){
			
			$email=$_POST['email'];
			$passwd=$_POST['passwd'];
			
			// comrobamos la base de datos y nos guardamos el email y la contraseña 

			
			$db=conecta($dbhost, $dbuser, $dbpasswd, $dbname);
			$sql='SELECT * FROM users WHERE email="'.$email.'" AND passwd="'.$passwd.'";';

			// hacemos la consulta y la guardamos en la variable sql

			if($result = mysqli_query($db,$sql)){

				//ejecutamos la consulta y la guardamos en la variable result

				if ($row = mysqli_fetch_array($result)) {
                       
					//guardamos en row el array con el resultado (siempre nos dará un array aunque el resultado solo sea uno)

                       $_SESSION['email'] = $email; 
                       $_SESSION['passwd'] = $passwd;
                                                        
                       setcookie('email', $email, time()+1800, '/todo', '');
                       setcookie('passwd', $passwd, time()+1800, '/todo', '');

                       //guardamos información de las cookies

                        header('Location:list.php'); //para que la cabecera sea list.php
                        exit();
                }
                else{
                	
                    header('Location:index.html'); //si la consulta está vacia significa que nos hemos equivocado en el email, en la contraseña o que no existe, por lo tanto la cabecera será la página principal

                    exit();
                 }

			}

			else{

				die('Error de connexió');
				header('Location:index.html'); //si no nos podemos conectar con la base de datos nos enviará a index.html

			} 
		}
	}


?>


<!DOCTYPE html>
	<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>TODO</title>
		<link rel="stylesheet" type="text/css" href="../assets/css/bootstrap.min.css">
		<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
	</head>
	<body>

<nav class="navbar navbar-inverse ">
			
			
		<div id="navbar" class="collapse navbar-collapse">
			<ul class="nav navbar-nav">
					
					<li><a href="../index.html"> Home </a></li>
					<li><a href="insert.php"> Registrar-se </a></li>
			
			</ul>
		</div>
			
	</nav>


<div class="jumbotron text-center">
	
	<h1>TODO</h1>
	<p>OLALLA IGLESIAS ALCALÁ</p>	



</div>

<div class="formgroup">

<form method="POST" action="<?= $_SERVER['PHP_SELF']; ?>">
			
			<p><label for="email">Email</label></p>

			<input class="form-control" type="text" name="email">

			<p><label for="passwd">Contraseña</label></p>

			<input class="form-control" type="password" name="passwd">

			<input value="Registrate" type="submit" name="Insert">

</div>

		<footer class="container-fluid">
			<h6> &copy; DAW2 - CEFP NURIA 2016 </h6>
		</footer>

	</body>
	</html>