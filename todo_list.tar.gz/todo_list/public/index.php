<?php

	if(!isset($_SESSION)) //Si la session no está vacia
	{
		session_start(); //iniciamos la sesión (para poder guardar las cookies)
	}

	$domain = $_SERVER['HTTP_HOST']; //guardamos el dominio

	if($domain=="oiglesias.cesnuria.com") //hacemos un if para no tener que cambiar la configuración de la base de datos cuando nos vayamos al servidor, de esta manerapodemos utilizar la misma carpeta tanto en el localhost de la máquina cómo en el servidor del cole

	{
		include '../lib/config.ini'; //incluir info del servidor de escoles nuria
	}

	else{
		 include '../lib/config.dev.ini'; //incluir info de localhost
	}



?>