<?php
        session_start();

                include '../lib/config.php';
                require '../lib/bd.php';

        if (!empty($_SESSION['id'])) { //si la variable de sesión no está vacia

                $id = $_SESSION['id']; //guardame en una variable el id de sesión
                $db = conecta($dbhost, $dbuser, $dbpasswd, $dbname);

                $sql ='DELETE FROM task WHERE id = "'.$id.'";';
                
                if($result=$db->query($sql)) //ejecutará la sentencia sql para borrar la tasca
                        {
                                header('Location:list.php');
                                exit();
                        }
                else
                        {
                                die("error en borrar"); //si no consigue ejecutarla nos dará error
                        }
        }
        else
        {
                header('Location:list.php');
                exit();
        }
        $db->close();
 ?>
